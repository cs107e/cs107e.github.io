#include "dma.h"
#include "malloc.h"

struct DMA_DESCRIPTOR *dma_init(const void *source_addr, void *dest_addr, uint32_t byte_count) {
    struct DMA_DESCRIPTOR *dma_descriptor = malloc(sizeof(struct DMA_DESCRIPTOR));
    dma_descriptor->config = 0; // fix?
    dma_descriptor->source_addr = (uint32_t)((uint64_t)source_addr & 0xffffffff);
    dma_descriptor->dest_addr = (uint32_t)((uint64_t)dest_addr & 0xffffffff);
    dma_descriptor->byte_count = byte_count;
    dma_descriptor->parameter.WAIT_CLOCK_CYCLES = 0;
    dma_descriptor->parameter.HIGH2_SRC = (uint32_t)(((uint64_t)source_addr >> 32) & 0x3);
    dma_descriptor->parameter.HIGH2_DEST = (uint32_t)(((uint64_t)dest_addr >> 32) & 0x3);
    dma_descriptor->link.full = 0xFFFFF800; // only one memory address
    
    struct DMA *dmac = (struct DMA *)DMAC_BASE;
    dmac->dmac_channel[0].dmac_cfg_regn.DMA_DEST_DATA_WIDTH = 2; // 32 bit
    dmac->dmac_channel[0].dmac_cfg_regn.DMA_ADDR_MODE = 1; // IO mode 
    return dma_descriptor;
}
