## 3D Graphics Library Winter 2024

## Team members

By Daniel James and Ege Turan

## Project description

A reusable, generic 3d rendering library. The library features arbitrary models
and instances, object translation, rotation, and scaling, camera movement and
rotation, model file loading, and configurable lighting all with high
performance. 

## Member contribution

We wrote almost all the code together working on each others computers to make
sure that we really understood everything that was going on. Right at the start
Daniel wrote `math.c` while Ege did `linalg.c`. Near the end Ege did more of the
work on the light engine and Daniel wrote the Rubik's Cube demo. But most of the
code was collaborative.

## References

We relied heavily on this book: https://gabrielgambetta.com/computer-graphics-from-scratch/00-introduction.html
for the ideas behind the engine as well as the underlying math. Where we used
specific formulas from external resources they are sited in the code.

## Self-evaluation

We are really proud of how the project came out. We achieved everything we 
wanted to and the project has excellent performance and works great.

