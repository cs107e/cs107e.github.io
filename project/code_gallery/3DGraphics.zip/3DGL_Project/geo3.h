/* File: geo3.h
 * ----------
 * Geometric shapes.
 * 
 * Authors: Ege, Daniel
 */

#include "linalg.h"
#include "malloc.h"

#ifndef GEO3_H
#define GEO3_H

typedef unsigned int color_t; // TODO

typedef struct {
    int width, height;
} Canvas;

typedef struct {
    float dist;
    float v_width, v_height;
    Vec3 position;
    Vec3 rotation;
} Camera;

typedef enum {
    SHADER_OFF,
    SHADER_FLAT,
    SHADER_GOURAUD
} ShaderType;

typedef struct {
    color_t background;
    ShaderType shader;
} SceneConfig;

typedef unsigned short VertexIdx;
typedef short NormalIdx;
typedef unsigned short TriangleIdx;
typedef unsigned short ModelIdx;
typedef unsigned short InstanceIdx;

typedef unsigned short LightIdx;    // TODO

#define NO_NORMAL (-1)

typedef struct {
    VertexIdx v1, v2, v3;
    NormalIdx vn1, vn2, vn3;
    color_t color;
} Triangle;

typedef struct {
    Vec4 *vertices;
    Vec4 *normals;
    Triangle *triangles;

    int vertex_cnt;
    int normal_cnt;
    int triangle_cnt;

    Vec4 model_center;
    float model_radius;
} Model;

typedef struct {
    ModelIdx model;
    float scale;
    Vec3 position;
    Vec3 rotation;
} Instance;

Model new_model(
    Vec3 vertices[],
    Vec3 normals[],
    Triangle triangles[],
    int vertex_cnt,
    int normal_cnt,
    int triangle_cnt
);

typedef struct {
    Vec3 normal;
    float d;
} ClipPlane;

float clip_signed_dist(ClipPlane plane, Vec3 v);

#endif