/* File: math.h
 * ----------
 * Advanced mathmatical functions on floating point functions.
 * 
 * Authors: Ege, Daniel
 */

#ifndef MATH_H
#define MATH_H

#define PI             3.141592653
#define TAU            6.283185307
#define HALF_PI        1.570796327
#define QUARTER_PI     0.785398163

#define INV_PI         0.31830988618
#define INV_TAU        0.15915494309
#define INV_HALF_PI    0.63661977236
#define INV_QUARTER_PI 1.27323954474

#define SQRT_2         1.41421356237
#define INV_SQRT_2     0.70710678118

void enable_floats(void);

float sin(float theta);
float cos(float theta);
float tan(float theta);

float fmin(float a, float b);
float fmax(float a, float b);

extern float fsqrt(float x);

float fabs(float x);
float fmod(float x, float y);

#endif