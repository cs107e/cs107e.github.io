// #include "../resources/suzanne.stl.h"
#include "../resources/suzanne.obj.h"
#include "uart.h"
#include "../gl3.h"
#include "../loaders.h"
#include "../math.h"
#include "printf.h"
#include "interrupts.h"
#include "gpio_interrupt.h"
#include "assert.h"

typedef struct {
    char key;
    Vec3 delta;
    Vec3 rot_delta;
} KeyControl;

static const KeyControl KEYS[] = {
    { 'w', {  0,  0,  1 }, {  0,  0, 0 } },
    { 's', {  0,  0, -1 }, {  0,  0, 0 } },
    { 'a', { -1,  0,  0 }, {  0,  0, 0 } },
    { 'd', {  1,  0,  0 }, {  0,  0, 0 } },
    { ' ', {  0,  1,  0 }, {  0,  0, 0 } },
    { 'x', {  0, -1,  0 }, {  0,  0, 0 } },
    { 'q', {  0,  0,  0 }, {  0,  1, 0 } },
    { 'e', {  0,  0,  0 }, {  0, -1, 0 } },
    { 'u', {  0,  0,  0 }, {  1,  0, 0 } },
    { 'j', {  0,  0,  0 }, { -1,  0, 0 } }
};
static const int KEYS_LEN = sizeof(KEYS) / sizeof(KEYS[0]);

static void control_scene() {
    static const float MOVE_SPEED = 4;
    static const float ROTATE_SPEED = 0.6;

    static int held_keys = 0;

    Vec3 move_delta = { 0, 0, 0 };
    Vec3 rot_delta = { 0, 0, 0 };
    for (int i = 0; i < KEYS_LEN; i++) {
        if ((held_keys & (1 << i)) != 0) {
            move_delta = vec_add3(move_delta, KEYS[i].delta);
            rot_delta = vec_add3(rot_delta, KEYS[i].rot_delta);
        }
    }

    Camera *camera = gl3_get_camera();
    Light *point = gl3_get_light(1);

    rot_delta = scale3(rot_delta, ROTATE_SPEED * gl3_time_delta());
    camera->rotation = vec_add3(camera->rotation, rot_delta);

    if (move_delta.x != 0 || move_delta.y != 0 || move_delta.z != 0) {
        move_delta = normalize3(move_delta);
        move_delta = scale3(move_delta, MOVE_SPEED * gl3_time_delta());

        Vec3 hor_rot = { 0, camera->rotation.y, 0 };
        Matrix4x4 rot_mat = get_rot_matrix(hor_rot);

        Vec4 projected_move_delta = mat_vec_mult(rot_mat, cartesian_to_homogenous(move_delta));
        camera->position = vec_add3(camera->position, homogenous_to_cartesian(projected_move_delta));
    }

    if (uart_haschar()) {
        char ch = uart_getchar();
        uart_putchar(ch); // echo
        for (int i = 0; i < KEYS_LEN; i++) {
            if (ch != KEYS[i].key) continue;
            int bit = 1 << i;
            if (held_keys & bit) {
                held_keys &= ~bit;
            } else {
                held_keys |= bit;
            }
            printf("\t["); // show held keys
            for (int i = 0; i < KEYS_LEN; i++)
                if (held_keys & (1 << i)) uart_putchar(KEYS[i].key);
            printf("]\n");
            return;
        }

        if (ch == 'c') {
            camera->position = (Vec3){0, 0, 0};
            camera->rotation = (Vec3){0, 0, 0};
        } else if (ch == '0') {
            gl3_get_scene_config()->shader = SHADER_OFF;
        } else if (ch == '1') {
            gl3_get_scene_config()->shader = SHADER_FLAT;
        } else if (ch == '2') {
            gl3_get_scene_config()->shader = SHADER_GOURAUD;
        } else if (ch == '5') {
            point->position.x += 1;
        } else if (ch == '6') {
            point->position.x -= 1;
        } else if (ch == '7') {
            point->position.y -= 1;
        } else if (ch == '8') {
            point->position.y += 1;
        }
        if (ch == '\e') mango_reboot();// escape => exit
        uart_putchar('\n');
    }
}

void main(void) {
    uart_init();
    gl3_init(800, 600, GL3_WHITE);

    Light ambient = gl3_new_ambient_light(0.5);
    Light point = gl3_new_point_light(0.3, (Vec3){ -2, 4, 8 });

    gl3_add_light(ambient);
    gl3_add_light(point);

    Model suzanne_model;
    assert(gl3_load_obj((const char *)resources_suzanne_obj, resources_suzanne_obj_len, GL3_GREEN, &suzanne_model));
    ModelIdx suzanne_model_idx = gl3_add_model(suzanne_model);
    InstanceIdx suzanne_instance_idx = gl3_add_instance(suzanne_model_idx);

    Instance *suzanne_instance = gl3_get_instance(suzanne_instance_idx);
    suzanne_instance->scale = 2;
    suzanne_instance->position.z = 7;
    suzanne_instance->rotation.y = PI;
    suzanne_instance->rotation.x = 0;

    printf("Starting\n");

    while (1) {
        suzanne_instance->rotation.y += HALF_PI * gl3_time_delta();

        control_scene();

        gl3_render_frame();
        gl3_swap();
    }
}