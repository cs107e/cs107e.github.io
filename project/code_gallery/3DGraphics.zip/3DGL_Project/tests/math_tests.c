#include "assert.h"
#include "../math.h"
#include "printf.h"

float fcmp(float x, float y) {
    return fabs(x - y);
}

#define EPSILON 0.001
#define f_assert_eq(x, y) assert(fcmp(x, y) < EPSILON)

void test_fabs(void) {
    assert(fabs(1.0) == 1.0);
    assert(fabs(0.0) == 0.0);
    assert(fabs(-1.0) == 1.0);
}

void test_fmod(void) {
    assert(fmod(0.0, 1.0) == 0.0);
    assert(fmod(0.0, 10.0) == 0.0);

    assert(fmod(3.0, 10.0) == 3.0);
    assert(fmod(10.0, 10.0) == 0.0);

    assert(fmod(11.0, 10.0) == 1.0);
    assert(fmod(114.0, 10.0) == 4.0);

    assert(fmod(2.5, 7.5) == 2.5);
    assert(fmod(2.5, 2.5) == 0.0);
    assert(fmod(7.5, 2.5) == 0.0);
    assert(fmod(8.0, 2.5) == 0.5);

    assert(fmod(-1.0, 2.0) == -1.0);
    assert(fmod(-1.0, -2.0) == -1.0);
    assert(fmod(-3.0, -2.0) == -1.0);

    f_assert_eq(fmod(PI + HALF_PI, PI), HALF_PI);
}

void test_min_max(void) {
    assert(fmin(0, 1) == 0);
    assert(fmin(1, 1) == 1);
    assert(fmin(4, 1) == 1);
    assert(fmin(-3, 1) == -3);
    assert(fmin(-5, -2) == -5);

    assert(fmax(0, 1) == 1);
    assert(fmax(1, 1) == 1);
    assert(fmax(4, 1) == 4);
    assert(fmax(-3, 1) == 1);
    assert(fmax(-5, -2) == -2);
}

void test_sine(void) {
    f_assert_eq(sin(0.0), 0.0);
    f_assert_eq(sin(HALF_PI), 1.0);
    f_assert_eq(sin(PI), 0.0);
    f_assert_eq(sin(-PI), 0.0);
    f_assert_eq(sin(-HALF_PI), -1.0);
    f_assert_eq(sin(1.5 * PI), -1.0);

    f_assert_eq(sin(-2.723790453), -0.4057526833);
    f_assert_eq(sin(-4.414471984), +0.9559499859);
    f_assert_eq(sin(+0.2803496694), +0.2766916834);
    f_assert_eq(sin(+6.366983953), +0.08370060488);
    f_assert_eq(sin(-7.149792992), -0.7621370886);
    f_assert_eq(sin(-7.943067224), -0.9960345025);
    f_assert_eq(sin(-7.079725568), -0.7149413786);
    f_assert_eq(sin(+5.556374889), -0.664489452);
    f_assert_eq(sin(-3.059107585), -0.08239156479);
    f_assert_eq(sin(-3.647052137), +0.484209517);
}

void test_cosine(void) {
    f_assert_eq(cos(0.0), 1.0);
    f_assert_eq(cos(HALF_PI), 0.0);
    f_assert_eq(cos(PI), -1.0);
    f_assert_eq(cos(-PI), -1.0);
    f_assert_eq(cos(-HALF_PI), 0.0);
    f_assert_eq(cos(1.5 * PI), 0.0);

    f_assert_eq(cos(-4.648790077), -0.06355603769);
    f_assert_eq(cos(-4.463171411), -0.2466457767);
    f_assert_eq(cos(+6.10738546), +0.9845869641);
    f_assert_eq(cos(-8.832579084), -0.8297153022);
    f_assert_eq(cos(-2.488859703), -0.794426883);
    f_assert_eq(cos(-1.257814733), +0.3078967481);
    f_assert_eq(cos(+2.582674993), -0.8478295384);
    f_assert_eq(cos(-0.6648179993), +0.7870290773);
    f_assert_eq(cos(+1.47291261), +0.09772748453);
    f_assert_eq(cos(+2.102860849), -0.5073135466);
}

void test_tangent(void) {
    f_assert_eq(tan(0.0), 0.0);
    f_assert_eq(tan(PI), 0.0);
    f_assert_eq(tan(-PI), 0.0);

    f_assert_eq(tan(-5.890109644), +0.4146548243);
    f_assert_eq(tan(-9.211477118), +0.2165956858);
    f_assert_eq(tan(-4.697136272), -65.55704105);
    f_assert_eq(tan(-7.385026353), -1.973740153);
    f_assert_eq(tan(-0.4765906187), -0.5162850604);
    f_assert_eq(tan(+8.682997536), -0.9163596749);
    f_assert_eq(tan(-5.069187867), +2.682744582);
    f_assert_eq(tan(-4.775761256), +15.75864126);
    f_assert_eq(tan(-5.53648298), +0.9254556717);
    f_assert_eq(tan(+4.614046794), +10.13577412);
}

void test_sqrt(void) {
    f_assert_eq(fsqrt(4.0), 2.0);
    f_assert_eq(fsqrt(9.0), 3.0);
}

void main(void) {
    uart_init();
    enable_floats();

    test_fabs();
    test_fmod();
    test_min_max();

    test_sine();
    test_cosine();
    test_tangent();

    test_sqrt();
}