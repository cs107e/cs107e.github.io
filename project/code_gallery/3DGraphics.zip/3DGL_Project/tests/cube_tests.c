#include "../math.h"
#include "../gl3.h"
#include "uart.h"
#include "printf.h"
#include "timer.h"
#include "mango.h"

typedef struct {
    char key;
    Vec3 delta;
    Vec3 rot_delta;
} KeyControl;

static const KeyControl KEYS[] = {
    { 'w', {  0,  0,  1 }, {  0,  0, 0 } },
    { 's', {  0,  0, -1 }, {  0,  0, 0 } },
    { 'a', { -1,  0,  0 }, {  0,  0, 0 } },
    { 'd', {  1,  0,  0 }, {  0,  0, 0 } },
    { ' ', {  0,  1,  0 }, {  0,  0, 0 } },
    { 'x', {  0, -1,  0 }, {  0,  0, 0 } },
    { 'q', {  0,  0,  0 }, {  0,  1, 0 } },
    { 'e', {  0,  0,  0 }, {  0, -1, 0 } },
    { 'u', {  0,  0,  0 }, {  1,  0, 0 } },
    { 'j', {  0,  0,  0 }, { -1,  0, 0 } }
};
static const int KEYS_LEN = sizeof(KEYS) / sizeof(KEYS[0]);

static int held_keys = 0;

static void move_camera() {
    static const float MOVE_SPEED = 4;
    static const float ROTATE_SPEED = 0.6;

    Vec3 move_delta = { 0, 0, 0 };
    Vec3 rot_delta = { 0, 0, 0 };
    for (int i = 0; i < KEYS_LEN; i++) {
        if ((held_keys & (1 << i)) != 0) {
            move_delta = vec_add3(move_delta, KEYS[i].delta);
            rot_delta = vec_add3(rot_delta, KEYS[i].rot_delta);
        }
    }

    Camera *camera = gl3_get_camera();

    rot_delta = scale3(rot_delta, ROTATE_SPEED * gl3_time_delta());
    camera->rotation = vec_add3(camera->rotation, rot_delta);

    if (move_delta.x != 0 || move_delta.y != 0 || move_delta.z != 0) {
        move_delta = normalize3(move_delta);
        move_delta = scale3(move_delta, MOVE_SPEED * gl3_time_delta());

        Vec3 hor_rot = { 0, camera->rotation.y, 0 };
        Matrix4x4 rot_mat = get_rot_matrix(hor_rot);

        Vec4 projected_move_delta = mat_vec_mult(rot_mat, cartesian_to_homogenous(move_delta));
        camera->position = vec_add3(camera->position, homogenous_to_cartesian(projected_move_delta));
    }

    if (uart_haschar()) {
        char ch = uart_getchar();
        uart_putchar(ch); // echo
        for (int i = 0; i < KEYS_LEN; i++) {
            if (ch != KEYS[i].key) continue;
            int bit = 1 << i;
            if (held_keys & bit) {
                held_keys &= ~bit;
            } else {
                held_keys |= bit;
            }
            printf("\t["); // show held keys
            for (int i = 0; i < KEYS_LEN; i++)
                if (held_keys & (1 << i)) uart_putchar(KEYS[i].key);
            printf("]\n");
            return;
        }

        if (ch == 'c') {
             Camera *camera = gl3_get_camera();
             camera->position = (Vec3){0, 0, 0};
             camera->rotation = (Vec3){0, 0, 0};
        } else if (ch == '0') {
             gl3_get_scene_config()->shader = SHADER_OFF;
        } else if (ch == '1') {
             gl3_get_scene_config()->shader = SHADER_FLAT;
        } else if (ch == '2') {
             gl3_get_scene_config()->shader = SHADER_GOURAUD;
        }
        if (ch == '\e') mango_reboot();// escape => exit
        uart_putchar('\n');
    }
}

void main(void) {
    uart_init();
    gl3_init(800, 600, GL3_WHITE);

    Model cube = new_model(
        (Vec3[]){
            { 1,  1,  1},
            {-1,  1,  1},
            {-1, -1,  1},
            { 1, -1,  1},
            { 1,  1, -1},
            {-1,  1, -1},
            {-1, -1, -1},
            { 1, -1, -1}
        },
        NULL,
        (Triangle[]){
            { 0, 1, 2, NO_NORMAL, NO_NORMAL, NO_NORMAL, GL3_RED },
            { 0, 2, 3, NO_NORMAL, NO_NORMAL, NO_NORMAL, GL3_RED },
            { 4, 0, 3, NO_NORMAL, NO_NORMAL, NO_NORMAL, GL3_GREEN },
            { 4, 3, 7, NO_NORMAL, NO_NORMAL, NO_NORMAL, GL3_GREEN },
            { 5, 4, 7, NO_NORMAL, NO_NORMAL, NO_NORMAL, GL3_BLUE },
            { 5, 7, 6, NO_NORMAL, NO_NORMAL, NO_NORMAL, GL3_BLUE },
            { 1, 5, 6, NO_NORMAL, NO_NORMAL, NO_NORMAL, GL3_YELLOW },
            { 1, 6, 2, NO_NORMAL, NO_NORMAL, NO_NORMAL, GL3_YELLOW },
            { 4, 5, 1, NO_NORMAL, NO_NORMAL, NO_NORMAL, GL3_PURPLE },
            { 4, 1, 0, NO_NORMAL, NO_NORMAL, NO_NORMAL, GL3_PURPLE },
            { 2, 6, 7, NO_NORMAL, NO_NORMAL, NO_NORMAL, GL3_CYAN },
            { 2, 7, 3, NO_NORMAL, NO_NORMAL, NO_NORMAL, GL3_CYAN }
        },
        8,
        0,
        12
    );

    ModelIdx cube_model = gl3_add_model(cube);
    InstanceIdx cube_instance1 = gl3_add_instance(cube_model);
    InstanceIdx cube_instance2 = gl3_add_instance(cube_model);
    gl3_get_instance(cube_instance1)->position.z = 7;
    gl3_get_instance(cube_instance2)->position.z = 7;
    gl3_get_instance(cube_instance2)->position.x = -3;
    gl3_get_instance(cube_instance2)->scale = 0.5;

    Light ambient = gl3_new_ambient_light(0.5);
    Light point = gl3_new_point_light(0.8, (Vec3){ -2, 4, 8 });

    gl3_add_light(ambient);
    gl3_add_light(point);

    printf("Starting\n");

    float delta = 4;
    while (1) {
        Instance *instance = gl3_get_instance(cube_instance1);
        instance->position.y += delta * gl3_time_delta();
        instance->rotation.y += delta * gl3_time_delta();

        if (instance->position.y < -5 || instance->position.y > 5) delta *= -1;

        move_camera();

        gl3_render_frame();        
        gl3_swap();

        //printf("frame time ms = %f\n", gl3_time_delta() * 1000.0);
  }
} 