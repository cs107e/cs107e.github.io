#include "../math.h"
#include "../gl3.h"
#include "uart.h"
#include "printf.h"
#include "timer.h"
#include "assert.h"

#define MIN(a, b) ((a) < (b) ? (a) : (b))
#define MAX(a, b) ((a) > (b) ? (a) : (b))

color_t COLORS[] = {
    0xffffffff, // white
    0xffFF5800, // orange
    0xffFED602, // yellow
    0xffB80830, // red
    0xff0044AE, // blue
    0xff009C46, // green
};

typedef struct {
    char key;
    float theta_delta;
    float phi_delta;
} KeyControl;

static const KeyControl KEYS[] = {
    { 'w', -1,  0 },
    { 's',  1,  0 },
    { 'a',  0, -1 },
    { 'd',  0,  1 }
};
static const int KEYS_LEN = sizeof(KEYS) / sizeof(KEYS[0]);

InstanceIdx all_cubes[3 * 3 * 3];

int get_cube_idx(int x, int y, int z) {
    return (x + 1) + (y + 1) * 3 + (z + 1) * 9; 
}

int spinning_face = 0;
float spin_remaining = 0.0;

typedef struct {
    bool x, y, z;
    int off;
} FaceInfo;

FaceInfo face_infos[6] = {
    { true, true, false,  1 },
    { true, true, false, -1 },
    { true, false, true,  1 },
    { true, false, true, -1 },
    { false, true, true,  1 },
    { false, true, true, -1 },
};

void set_spin(int face) {
    if (spin_remaining > 0) return;

    spinning_face = face;
    spin_remaining = HALF_PI;
}

int simple_round(float x) {
    if (x > 0.5) {
        return 1;
    } else if (x < -0.5) {
        return -1;
    } else {
        return 0;
    }
}

Vec3 face_to_norm(int face) {
    switch (face) {
    case 0: return (Vec3){  0,  0,  1 };
    case 1: return (Vec3){  1,  0,  0 };
    case 2: return (Vec3){  0,  0, -1 };
    case 3: return (Vec3){ -1,  0,  0 };
    case 4: return (Vec3){  0,  1,  0 };
    case 5: return (Vec3){  0, -1,  0 };
    }

    assert(false);
    return (Vec3){0, 0, 0};
}

int norm_to_face(Vec3 norm) {
    int x = simple_round(norm.x);
    int y = simple_round(norm.y);
    int z = simple_round(norm.z);

    if (x ==  0 && y ==  0 && z ==  1) return 0;
    if (x ==  1 && y ==  0 && z ==  0) return 1;
    if (x ==  0 && y ==  0 && z == -1) return 2;
    if (x == -1 && y ==  0 && z ==  0) return 3;
    if (x ==  0 && y ==  1 && z ==  0) return 4;
    if (x ==  0 && y == -1 && z ==  0) return 5;

    assert(false);
    return 0;
}

void fix_indicies(void) {
    // undo rotation
    FaceInfo fi = face_infos[spinning_face];
    for (int x = fi.x ? -1 : fi.off; x <= (fi.x ? 1 : fi.off); x++) {
        for (int y = fi.y ? -1 : fi.off; y <= (fi.y ? 1 : fi.off); y++) {
            for (int z = fi.z ? -1 : fi.off; z <= (fi.z ? 1 : fi.off); z++) {
                int idx = get_cube_idx(x, y, z);

                Instance *instance = gl3_get_instance(all_cubes[idx]);
                if (!fi.x) instance->rotation.x -= HALF_PI;
                if (!fi.y) instance->rotation.y -= HALF_PI;
                if (!fi.z) instance->rotation.z -= HALF_PI;
            }
        }
    }

    // find what all the face colors currently are
    color_t face_colors[3 * 3 * 3 * 6];
    for (int x = -1; x <= 1; x++) {
        for (int y = -1; y <= 1; y++) {
            for (int z = -1; z <= 1; z++) {
                int idx = get_cube_idx(x, y, z);
                Model *model = gl3_get_model(all_cubes[idx]);
                for (int f = 0; f < 6; f++) {
                    face_colors[idx * 6 + f] = model->triangles[f * 2].color;
                }
            }
        }
    }

    // repaint faces
    Matrix4x4 rot_mat = get_rot_matrix((Vec3){
        fi.x ? 0 : -HALF_PI,
        fi.y ? 0 : -HALF_PI,
        fi.z ? 0 : -HALF_PI,
    });

    for (int x = fi.x ? -1 : fi.off; x <= (fi.x ? 1 : fi.off); x++) {
        for (int y = fi.y ? -1 : fi.off; y <= (fi.y ? 1 : fi.off); y++) {
            for (int z = fi.z ? -1 : fi.off; z <= (fi.z ? 1 : fi.off); z++) {
                Vec4 previous_h = cartesian_to_homogenous((Vec3){x, y, z});
                previous_h = mat_vec_mult(rot_mat, previous_h);
                Vec3 previous = homogenous_to_cartesian(previous_h);

                int p_idx = get_cube_idx(simple_round(previous.x), simple_round(previous.y), simple_round(previous.z));
                int idx = get_cube_idx(x, y, z);
                Model *model = gl3_get_model(all_cubes[idx]);

                for (int f = 0; f < 6; f++) {
                    Vec3 norm = face_to_norm(f);
                    Vec4 p_norm_h = cartesian_to_homogenous(norm);
                    p_norm_h = mat_vec_mult(rot_mat, p_norm_h);
                    Vec3 p_norm = homogenous_to_cartesian(p_norm_h);
                    int p_f = norm_to_face(p_norm);

                    model->triangles[f * 2 + 0].color = face_colors[p_idx * 6 + p_f];
                    model->triangles[f * 2 + 1].color = face_colors[p_idx * 6 + p_f];
                }
            }
        }
    }
}

void spin_face() {
    if (spin_remaining == 0) return;

    float spin_delta = PI * gl3_time_delta();
    spin_delta = MIN(spin_delta, spin_remaining);
    spin_remaining -= spin_delta;

    FaceInfo fi = face_infos[spinning_face];

    for (int x = fi.x ? -1 : fi.off; x <= (fi.x ? 1 : fi.off); x++) {
        for (int y = fi.y ? -1 : fi.off; y <= (fi.y ? 1 : fi.off); y++) {
            for (int z = fi.z ? -1 : fi.off; z <= (fi.z ? 1 : fi.off); z++) {
                int idx = get_cube_idx(x, y, z);

                Instance *instance = gl3_get_instance(all_cubes[idx]);
                if (!fi.x) instance->rotation.x += spin_delta;
                if (!fi.y) instance->rotation.y += spin_delta;
                if (!fi.z) instance->rotation.z += spin_delta;
            }
        }
    }

    if (spin_remaining == 0) fix_indicies();
}

static void move_camera() {
    static const float MOVE_SPEED = 3.0 * PI / 4.0;

    static const float CAMERA_RADIUS = 8.0;
    static float camera_theta = HALF_PI;
    static float camera_phi = 0;

    static int held_keys = 0;

    float theta_delta = 0;
    float phi_delta = 0;
    for (int i = 0; i < KEYS_LEN; i++) {
        if ((held_keys & (1 << i)) != 0) {
            theta_delta = KEYS[i].theta_delta;
            phi_delta = KEYS[i].phi_delta;
        }
    }
    theta_delta *= MOVE_SPEED * gl3_time_delta();
    phi_delta *= MOVE_SPEED * gl3_time_delta();

    camera_theta += theta_delta;
    camera_theta = MIN(MAX(camera_theta, QUARTER_PI), 3*QUARTER_PI);
    camera_phi += phi_delta;

    Camera *camera = gl3_get_camera();

    // https://en.wikipedia.org/wiki/Spherical_coordinate_system#Cartesian_coordinates
    camera->position.x = CAMERA_RADIUS * sin(camera_theta) * cos(camera_phi);
    camera->position.z = CAMERA_RADIUS * sin(camera_theta) * sin(camera_phi);
    camera->position.y = CAMERA_RADIUS * cos(camera_theta);

    camera->rotation.x = camera_theta - HALF_PI;
    camera->rotation.y = camera_phi + HALF_PI;

    if (uart_haschar()) {
        char ch = uart_getchar();
        uart_putchar(ch); // echo
        for (int i = 0; i < KEYS_LEN; i++) {
            if (ch != KEYS[i].key) continue;
            int bit = 1 << i;
            if (held_keys & bit) {
                held_keys &= ~bit;
            } else {
                held_keys |= bit;
            }
            printf("\t["); // show held keys
            for (int i = 0; i < KEYS_LEN; i++)
                if (held_keys & (1 << i)) uart_putchar(KEYS[i].key);
            printf("]\n");
            return;
        }

        while (camera_phi < 0) camera_phi += 2 * PI;

        switch(ch) {
            case '1': set_spin(0); break;
            case '2': set_spin(1); break;
            case '3': set_spin(2); break;
            case '4': set_spin(3); break;
            case '5': set_spin(4); break;
            case '6': set_spin(5); break;           
            case ' ': {
                if (camera_theta < QUARTER_PI * 1.25 ) {
                    set_spin(2);
                } else if (camera_theta > 2.75 * QUARTER_PI) {
                    set_spin(3);
                } else {
                    float phi = camera_phi + QUARTER_PI;
                    switch ((int)(fmod(phi, 2 * PI) / HALF_PI) % 4) {
                    case 0: set_spin(4); break;
                    case 1: case -1: set_spin(0); break;
                    case 2: case -2: set_spin(5); break;
                    case 3: case -3: set_spin(1); break;
                    }
                }
            }
        }
        if (ch == '\e') mango_reboot();// escape => exit
    }
}

Model make_cube_model(Vec3 offset) {
    return new_model(
        (Vec3[]){
            vec_add3((Vec3){ 0.5,  0.5,  0.5}, offset),
            vec_add3((Vec3){-0.5,  0.5,  0.5}, offset),
            vec_add3((Vec3){-0.5, -0.5,  0.5}, offset),
            vec_add3((Vec3){ 0.5, -0.5,  0.5}, offset),
            vec_add3((Vec3){ 0.5,  0.5, -0.5}, offset),
            vec_add3((Vec3){-0.5,  0.5, -0.5}, offset),
            vec_add3((Vec3){-0.5, -0.5, -0.5}, offset),
            vec_add3((Vec3){ 0.5, -0.5, -0.5}, offset)
        },
        NULL,
        (Triangle[]){
            { 0, 1, 2, NO_NORMAL, NO_NORMAL, NO_NORMAL, offset.z > 0 ? COLORS[0] : GL3_BLACK },
            { 0, 2, 3, NO_NORMAL, NO_NORMAL, NO_NORMAL, offset.z > 0 ? COLORS[0] : GL3_BLACK },
            { 4, 0, 3, NO_NORMAL, NO_NORMAL, NO_NORMAL, offset.x > 0 ? COLORS[1] : GL3_BLACK },
            { 4, 3, 7, NO_NORMAL, NO_NORMAL, NO_NORMAL, offset.x > 0 ? COLORS[1] : GL3_BLACK },
            { 5, 4, 7, NO_NORMAL, NO_NORMAL, NO_NORMAL, offset.z < 0 ? COLORS[2] : GL3_BLACK },
            { 5, 7, 6, NO_NORMAL, NO_NORMAL, NO_NORMAL, offset.z < 0 ? COLORS[2] : GL3_BLACK },
            { 1, 5, 6, NO_NORMAL, NO_NORMAL, NO_NORMAL, offset.x < 0 ? COLORS[3] : GL3_BLACK },
            { 1, 6, 2, NO_NORMAL, NO_NORMAL, NO_NORMAL, offset.x < 0 ? COLORS[3] : GL3_BLACK },
            { 4, 5, 1, NO_NORMAL, NO_NORMAL, NO_NORMAL, offset.y > 0 ? COLORS[4] : GL3_BLACK },
            { 4, 1, 0, NO_NORMAL, NO_NORMAL, NO_NORMAL, offset.y > 0 ? COLORS[4] : GL3_BLACK },
            { 2, 6, 7, NO_NORMAL, NO_NORMAL, NO_NORMAL, offset.y < 0 ? COLORS[5] : GL3_BLACK },
            { 2, 7, 3, NO_NORMAL, NO_NORMAL, NO_NORMAL, offset.y < 0 ? COLORS[5] : GL3_BLACK }
        },
        8,
        0,
        12
    );
}

InstanceIdx add_cube_to_scene(Vec3 offset) {
    Model model = make_cube_model(offset);
    ModelIdx model_idx = gl3_add_model(model);
    return gl3_add_instance(model_idx);
}

void add_all_cubes(void) {
    float const GAP = 1.075;

    for (int x = -1; x <= 1; x++) {
        for (int y = -1; y <= 1; y++) {
            for (int z = -1; z <= 1; z++) {
                all_cubes[get_cube_idx(x, y, z)] = 
                    add_cube_to_scene((Vec3){x * GAP, y * GAP, z * GAP});
            }
        }
    }
}

void main(void) {
    uart_init();
    gl3_init(800, 600, GL3_WHITE);

    add_all_cubes();

    gl3_add_light(gl3_new_ambient_light(0.5));
    gl3_add_light(gl3_new_point_light(0.8, (Vec3){ 0, -8, -3 }));
    gl3_add_light(gl3_new_point_light(0.8, (Vec3){ 0, 8, 3 }));
    gl3_get_scene_config()->shader = SHADER_GOURAUD;

    printf("Starting\n");

    while (1) {
        move_camera();
        spin_face(spinning_face);

        gl3_render_frame();        
        gl3_swap();

        // printf("frame time ms = %f\n", gl3_time_delta() * 1000.0);
  }
} 