#ifndef GL3_H
#define GL3_H

#include "geo3.h"
#include "lights.h"

/*
 * `color_t`
 *
 * Define a type for color. We use BGRA colors, where each color
 * component R, B, G, or A is a single unsigned byte. The least
 * significant byte is the B component, and A is most significant.
 */
typedef unsigned int color_t;

/* Predefined colors
 */
#define GL3_BLACK    0xFF000000
#define GL3_WHITE    0xFFFFFFFF
#define GL3_RED      0xFFFF0000
#define GL3_GREEN    0xFF00FF00
#define GL3_BLUE     0xFF0000FF
#define GL3_CYAN     0xFF00FFFF
#define GL3_MAGENTA  0xFFFF00FF
#define GL3_YELLOW   0xFFFFFF00
#define GL3_AMBER    0xFFFFBF00
#define GL3_ORANGE   0xFFFF3F00
#define GL3_PURPLE   0xFF7F00FF
#define GL3_INDIGO   0xFF000040
#define GL3_CAYENNE  0xFF400000
#define GL3_MOSS     0xFF004000
#define GL3_SILVER   0xFFBBBBBB

/* Initializes the gl3 module. This takes control of the hdmi output. This also
 * allocates a fairly large amount of memory for various buffers. Keep that in
 * mind.
 * 
 * Width and height control the width and height the hdmi display will show.
 * Background controls the base background color of the scene.
 */
void gl3_init(int width, int height, color_t background);

/* Render the next frame. You should call this only after you have made all
 * the updates you need to make. This does not by itself display the scene it
 * only prepares it to be rendered. Call gl3_swap to display the newly rendered
 * frame.
 */
void gl3_render_frame(void);

/* Display the frame. *You must have called `gl3_render_frame` after your
 * previous call to gl3_swap or the behavior of calling this function is 
 * undefined.*
 */
void gl3_swap(void);

/* Returns the time in seconds between the last two calls to `gl3_swap`. This is
 * useful to make sure that movements/physics happen at a consistent speed
 * independent of the frame rate.
 */
float gl3_time_delta(void);


/* Adds a new model to the scene. This doesn't by itself display anything. You
 * will also need to add an instance of the model. This returns a ModelIdx
 * which you can use as a handle to talk to gl3 about the model.
 */
ModelIdx gl3_add_model(Model m);

/* Adds a new instance of a model to the scene. This returns the handel
 * InstanceIdx which you can use to modify the various properties of the
 * instance.
 */
InstanceIdx gl3_add_instance(ModelIdx ofModel);

/* Adds a new light to the scene. You can use the LightIdx handle to access the
 * light again.
 */
LightIdx gl3_add_light(Light light);

/* Returns a pointer to the instance specified by the InstanceIdx. You are free
 * to modify anything about the instance.
 */
Instance *gl3_get_instance(InstanceIdx idx);

/* Returns a pointer to the model of the instance specified by the InstanceIdx. 
 * You are free to modify anything about the model.
 */
Model *gl3_get_model(InstanceIdx idx);

/* Returns a pointer to the scene camera. *You may only modify the position and
 * rotation properties* and not the dist, v_width, and v_height properties.
 */
Camera *gl3_get_camera(void);

// TODO: comment
Light *gl3_get_light(LightIdx light_idx);

// TODO: comment
SceneConfig *gl3_get_scene_config(void);


#endif