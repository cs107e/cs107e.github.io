#include "geo3.h"
#include "linalg.h"
#include "math.h"

Model new_model(
    Vec3 vertices[],
    Vec3 normals[],
    Triangle triangles[],
    int vertex_cnt,
    int normal_cnt,
    int triangle_cnt
) {
    Model model;
    model.vertices = malloc(vertex_cnt * sizeof(Vec4));
    model.triangles = malloc(triangle_cnt * sizeof(Triangle));
    model.triangle_cnt = triangle_cnt;
    model.vertex_cnt = vertex_cnt;

    Vec3 calculated_norms[triangle_cnt];
    int calculated_norm_cnt = 0;

    for (int i = 0; i < triangle_cnt; i++) {
        Triangle tri = triangles[i];
        model.triangles[i] = tri;

        if (tri.vn1 == NO_NORMAL || tri.vn2 == NO_NORMAL || tri.vn3 == NO_NORMAL) {
            Vec3 v1 = vertices[tri.v1];
            Vec3 v2 = vertices[tri.v2];
            Vec3 v3 = vertices[tri.v3];
            Vec3 v21 = vec_sub3(v2, v1);
            Vec3 v31 = vec_sub3(v3, v1);
            Vec3 norm = cross_prod3(v21, v31);

            calculated_norms[calculated_norm_cnt++] = norm;
        }

        if (tri.vn1 == NO_NORMAL) model.triangles[i].vn1 = normal_cnt + calculated_norm_cnt - 1;
        if (tri.vn2 == NO_NORMAL) model.triangles[i].vn2 = normal_cnt + calculated_norm_cnt - 1;
        if (tri.vn3 == NO_NORMAL) model.triangles[i].vn3 = normal_cnt + calculated_norm_cnt - 1;
    }

    model.normal_cnt = normal_cnt + calculated_norm_cnt;
    model.normals = malloc(model.normal_cnt * sizeof(Vec4));

    Vec3 model_center = { 0, 0, 0 };
    for (int i = 0; i < vertex_cnt; i++) {
        model.vertices[i] = cartesian_to_homogenous(vertices[i]);
        model_center = vec_add3(model_center, vertices[i]);
    }
    model_center = scale3(model_center, 1 / (float)vertex_cnt);
    model.model_center = cartesian_to_homogenous(model_center);

    model.model_radius = 0;
    for (int i = 0; i < vertex_cnt; i++) {
        float dist = mag3(vec_sub3(model_center, vertices[i]));
        model.model_radius = fmax(model.model_radius, dist);
    }

    for (int i = 0; i < normal_cnt; i++) model.normals[i] = cartesian_to_homogenous(normals[i]);
    for (int i = 0; i < calculated_norm_cnt; i++) model.normals[normal_cnt + i] = cartesian_to_homogenous(calculated_norms[i]);

    return model;
}

float clip_signed_dist(ClipPlane plane, Vec3 v) {
    return v.x * plane.normal.x
         + v.y * plane.normal.y
         + v.z * plane.normal.z
         + plane.d;
}
