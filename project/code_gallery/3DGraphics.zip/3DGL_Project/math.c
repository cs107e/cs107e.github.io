#include "math.h"

extern void enable_floats(void);
extern float fsqrt(float);

// ------------------------------ Trigonometry ---------------------------------

// This is a polynomial approximation for sine in the range [-pi/2, pi/2]. It
// uses a Maclaurin series with terms up to x^13 and has a maximum error of
// 0.00000017881393 and an average error of 0.000000016385904.
static float restricted_sin(float x) {
    float xx = x * x;

    // We use this nested structure to avoid recompute the intermediate terms
    // in x^n. In reality this is equivelent to x^1 * c_1 + x^3 * c_2 + ...
    //
    // The constants are just the normal terms in the sin(x) taylor series at
    // x = 0. In theory it should be possible to create a better approximation
    // using the fact that we are operating in a restricted range. That is 
    // something to do more research into later. I tried for a bit to make
    // Chebyshev polynomials work based on this https://www.embeddedrelated.com/showarticle/152.php
    // article but they actually gave worse results for the same number of 
    // terms. Perhaps it is because sine is best approximated by only odd 
    // powers?
    //
    // Higher powers start to run into the floating point precision limit and
    // don't provide any extra accuracy.

    return x * (1.0               // x^1  / 1
     + xx * (-0.1666666667        // x^3  / 6
     + xx * (0.008333333333       // x^5  / 120
     + xx * (-0.0001984126984     // x^6  / 5040
     + xx * (0.000002755731922    // x^7  / 362880
     + xx * (-0.00000002505210839 // x^9  / 39916800
     + xx * 0.0000000001605904384 // x^11 / 6227020800
    ))))));
}

float sin(float theta) {
    float rem = fmod(theta, TAU);
    float bounded = fabs(rem);

    float result;
    // We split the region into four section of length PI/2. We can then 
    // calculate each of these sections using only the value of sin(x) in the
    // region from [0, PI/2].
    switch ((int)(bounded * INV_HALF_PI)) {
    case 0: result = restricted_sin(bounded); break;
    case 1: result = restricted_sin(PI - bounded); break;
    case 2: result = -restricted_sin(bounded - PI); break;
    default: result = -restricted_sin(TAU - bounded); break;
    }

    return rem < 0.0 ? -result : result;
}

float cos(float theta) {
    return sin(theta + HALF_PI);
}

float tan(float theta) {
    return sin(theta) / cos(theta);
}


// -------------------------- Simple Numerics ----------------------------------

float fabs(float x) {
    return x < 0 ? -x : x;
}

float fmin(float a, float b) {
    return a < b ? a : b;
}

float fmax(float a, float b) {
    return a > b ? a : b;
}

float fmod(float x, float y) {
    return x - y * (int)(x / y);
}