#include "gl3.h"
#include "math.h"
#include "linalg.h"
#include "strings.h"
#include "printf.h"
#include "de.h"
#include "hdmi.h"
#include "font.h"
#include "assert.h"
#include "timer.h"
#include "stdbool.h"

#define FONT_PIXEL_ON 0xff

#define MIN(x, y) ((x) < (y) ? (x) : (y))
#define MAX(x, y) ((x) > (y) ? (x) : (y))
#define ABS(x) ((x) >= 0 ? (x) : -(x))

#define FB_COUNT 3

#define MAX_MODELS 128
#define MAX_INSTANCES 128
#define MAX_LIGHTS 16

#define Z_BUF_DRAW_THRESHOLD (0)

void *get_draw_buffer(void);
static void clear_buffers(void);
static void calculate_clipping_planes(void);
static void render_instance(InstanceIdx idx, Matrix4x4 cam_transformations, Matrix4x4 cam_rots);
static void draw_debug_info(unsigned long elapsed_ticks);


static struct {
    Canvas canvas;
    Camera camera;

    Model models[MAX_MODELS];
    Instance instances[MAX_INSTANCES];
    ModelIdx model_cnt;
    InstanceIdx instance_cnt;

    Light lights[MAX_LIGHTS];
    Light transformed_lights[MAX_LIGHTS];
    LightIdx light_cnt;

    color_t *f_bufs[FB_COUNT];
    int cur_frame_buf;
    float *z_buf;

    SceneConfig config;

    unsigned long last_frame_start;
    float last_frame_time_s;
} module;

void gl3_init(int width, int height, color_t background) {
    enable_floats();

    module.canvas.width = width;
    module.canvas.height = height;

    for (int i = 0; i < FB_COUNT; i++) {
        module.f_bufs[i] = malloc(sizeof(color_t) * width * height);
    }
    module.cur_frame_buf = 0;
    module.z_buf = malloc(sizeof(float) * width * height);

    module.camera.dist = 3;
    module.camera.v_width = 5;
    module.camera.v_height = module.camera.v_width * (float)height / (float)width;
    module.camera.position = (Vec3){ 0, 0, 0 };
    module.camera.rotation = (Vec3){ 0, 0, 0 };

    module.config.background = background;
    module.config.shader = SHADER_FLAT;

    calculate_clipping_planes();

    gl3_render_frame();

    hdmi_resolution_id_t id = hdmi_best_match(width, height);
    hdmi_init(id);
    de_init(width, height, hdmi_get_screen_width(), hdmi_get_screen_height());
    de_set_active_framebuffer(module.f_bufs[0]);

    module.last_frame_start = timer_get_ticks();
    gl3_swap();
}

void gl3_render_frame(void) {
    long start_ticks = timer_get_ticks();

    clear_buffers();

    Matrix4x4 cam_rotations = get_rot_matrix(scale3(module.camera.rotation, -1.0F));
    Matrix4x4 cam_transformations = get_translation_matrix(scale3(module.camera.position, -1.0F));
    cam_transformations = mat_mult(cam_rotations, cam_transformations);

    for (int i = 0; i < module.light_cnt; i++) {
        Light og = module.lights[i];
        module.transformed_lights[i] = (Light){
            og.type,
            og.intensity,
            og.color,
            homogenous_to_cartesian(mat_vec_mult(cam_transformations, cartesian_to_homogenous(og.position))),
            homogenous_to_cartesian(mat_vec_mult(cam_rotations, cartesian_to_homogenous(og.direction)))
        };
    }

    for (InstanceIdx i = 0; i < module.instance_cnt; i++) {
        render_instance(i, cam_transformations, cam_rotations);
    }

    draw_debug_info(timer_get_ticks() - start_ticks);
}

void gl3_swap(void) {
    de_set_active_framebuffer(get_draw_buffer());
    module.cur_frame_buf++;
    module.cur_frame_buf %= FB_COUNT;

    unsigned long last_frame_start = module.last_frame_start;
    module.last_frame_start = timer_get_ticks();
    module.last_frame_time_s = (module.last_frame_start - last_frame_start) / TICKS_PER_USEC / 1000.0 / 1000.0;
}

float gl3_time_delta(void) {
    return module.last_frame_time_s;
}


ModelIdx gl3_add_model(Model m) {
    assert(module.model_cnt < MAX_MODELS);
    ModelIdx idx = module.model_cnt++;
    module.models[idx] = m;
    return idx;
}

InstanceIdx gl3_add_instance(ModelIdx ofModel) {
    assert(module.instance_cnt < MAX_INSTANCES);
    assert(ofModel < module.model_cnt);
    InstanceIdx idx = module.instance_cnt++;
    module.instances[idx].model = ofModel;
    module.instances[idx].scale = 1.0;
    module.instances[idx].position = (Vec3){ 0, 0, 0 };
    module.instances[idx].rotation = (Vec3){ 0, 0, 0 };
    return idx;
}

LightIdx gl3_add_light(Light light) {
    assert(module.light_cnt < MAX_LIGHTS);
    LightIdx idx = module.light_cnt++;
    module.lights[idx] = light;
    return idx;
}


Instance *gl3_get_instance(InstanceIdx idx) {
    assert(idx < module.instance_cnt);
    return &module.instances[idx];
}

Model *gl3_get_model(InstanceIdx idx) {
    assert(idx < module.instance_cnt);
    return &module.models[module.instances[idx].model];
}

Camera *gl3_get_camera(void) {
    return &module.camera;
}

Light *gl3_get_light(LightIdx light_idx) {
    return &module.lights[light_idx];
}

SceneConfig *gl3_get_scene_config(void) {
    return &module.config;
}

void *get_draw_buffer(void) {
    return module.f_bufs[module.cur_frame_buf];
}

static void clear_buffers(void) {
    // The bit pattern for float 0 and int 0 is the same but ints are loaded
    // faster.
    int *zb = (int *)module.z_buf;
    color_t *fb = get_draw_buffer();

    color_t background = module.config.background;
    int size = module.canvas.width * module.canvas.height;

    int i = 0;

    // This is to encourage the compiler to unroll the loop
    for (; i + 7 < size; i += 8) {
        for (int j = 0; j < 8; j++) {
            zb[i + j] = 0;
            fb[i + j] = background;
        }
    }

    for (; i < size; i++) {
        zb[i] = 0;
        fb[i] = background;
    }
}

#define POINT_SWAP(v1, c1, rgb1, v2, c2, rgb2) do { \
    Vec3 v_tmp = v1;      \
    v1 = v2;              \
    v2 = v_tmp;           \
                          \
    CanvasVec c_tmp = c1; \
    c1 = c2;              \
    c2 = c_tmp;           \
                          \
    Vec3 rgb_tmp = rgb1;  \
    rgb1 = rgb2;          \
    rgb2 = rgb_tmp;       \
} while(0)

CanvasVec viewport_to_canvas(Vec3 v) {
    // All the way on the right of the viewport is inclusive but it is 
    // exclusive on the canvas. So we want to not include the last pixel of 
    // the canvas. However floating point error means we never get a perfect
    // 1.0 so leave a little wiggle room to have the last pixel appear.
    float h_width = ((float)module.canvas.width - 0.99) / 2.0;
    float h_height = ((float)module.canvas.height) / 2.0;

    return (CanvasVec){
        .x = h_width + v.x * h_width / module.camera.v_width,
        // For computer screens positive y is down. But in world coordinates positive
        // y is up. That is why we invert the y value here.
        .y = h_height - v.y * h_height / module.camera.v_height,
    };
}

CanvasVec project_vertex(Vec3 v) {
    Vec3 projected = {
        .x = v.x * module.camera.dist / v.z,
        .y = v.y * module.camera.dist / v.z,
        .z = 0
    };

    return viewport_to_canvas(projected);
}

static void draw_triangle_3d(Vec3 v1, Vec3 v2, Vec3 v3, Vec3 vn1, Vec3 vn2, Vec3 vn3, color_t color) {
    Vec3 v21 = vec_sub3(v2, v1);
    Vec3 v31 = vec_sub3(v3, v1);

    Vec3 norm = cross_prod3(v21, v31);
    if ( dot_prod3(norm, v1) > 0 ) return;

    Vec3 rgb1, rgb2, rgb3;
    rgb1 = rgb2 = rgb3 = color_to_vector(color);

    if ( module.config.shader == SHADER_FLAT ) {
        Vec3 center = scale3(vec_add3(vec_add3(v1, v2), v3), 1.0/3.0);    
        rgb1 = rgb2 = rgb3 = light_color(color, norm, center, module.transformed_lights, module.light_cnt);
    } else if (module.config.shader == SHADER_GOURAUD) {
        rgb1 = light_color(color, vn1, v1, module.transformed_lights, module.light_cnt);        
        rgb2 = light_color(color, vn2, v2, module.transformed_lights, module.light_cnt); 
        rgb3 = light_color(color, vn3, v3, module.transformed_lights, module.light_cnt);     
    }

    CanvasVec c1 = project_vertex(v1);
    CanvasVec c2 = project_vertex(v2);
    CanvasVec c3 = project_vertex(v3);

    // First let's sort the vertices so that 1 is at the top and 3 at the bottom.
    if (c2.y < c1.y) { POINT_SWAP(v2, c2, rgb2, v1, c1, rgb1); }
    if (c3.y < c1.y) { POINT_SWAP(v3, c3, rgb3, v1, c1, rgb1); }
    if (c3.y < c2.y) { POINT_SWAP(v3, c3, rgb3, v2, c2, rgb2); }

    float x_l = (float)c1.x;
    float x_r = (float)c1.x;

    float x_l_step = c2.y == c1.y ? 1 : (float)(c2.x - c1.x) / (float)(c2.y - c1.y);
    float x_r_step = c3.y == c1.y ? 1 : (float)(c3.x - c1.x) / (float)(c3.y - c1.y);

    float iz_1 = 1 / v1.z;
    float iz_2 = 1 / v2.z;
    float iz_3 = 1 / v3.z;

    float iz_l = iz_1;
    float iz_r = iz_1;

    float iz_l_step = c2.y == c1.y ? 1 : (iz_2 - iz_1) / (float)(c2.y - c1.y);
    float iz_r_step = c3.y == c1.y ? 1 : (iz_3 - iz_1) / (float)(c3.y - c1.y);

    Vec3 rgb_l = rgb1;
    Vec3 rgb_r = rgb1;

    Vec3 rgb_l_step = scale3(vec_sub3(rgb2, rgb1), 1 / (float)(c2.y - c1.y));
    Vec3 rgb_r_step = scale3(vec_sub3(rgb3, rgb1), 1 / (float)(c3.y - c1.y));

    color_t *fb = get_draw_buffer();
    float *zb = module.z_buf;
    int width = module.canvas.width;

    // printf("here 2: %d -- %d\n", c1.y, c3.y);

    for (int y = c1.y; y < c3.y; y++) {
        if (y == c2.y) {
            x_l = c2.x;
            x_l_step = c3.y == c2.y ? 1 : (float)(c3.x - c2.x) / (float)(c3.y - c2.y);

            iz_l = iz_2;
            iz_l_step = c3.y == c2.y ? 1 : (iz_3 - iz_2) / (float)(c3.y - c2.y);

            rgb_l = rgb2;
            rgb_l_step = scale3(vec_sub3(rgb3, rgb2), 1 / (float)(c3.y - c2.y));
        }

        int x_min, x_max;
        float iz, iz_step;
        Vec3 rgb, rgb_step;

        if (x_l < x_r) {
            x_min = x_l;
            x_max = x_r;
            iz = iz_l;
            iz_step = x_max == x_min ? 1 : (iz_r - iz_l) / (float)(x_max - x_min);
            rgb = rgb_l;
            rgb_step = scale3(vec_sub3(rgb_r, rgb_l), 1 / (float)(x_max - x_min));
        } else {
            x_min = x_r;
            x_max = x_l;
            iz = iz_r;
            iz_step = x_max == x_min ? 1 : (iz_l - iz_r) / (float)(x_max - x_min);
            rgb = rgb_r;
            rgb_step = scale3(vec_sub3(rgb_l, rgb_r), 1 / (float)(x_max - x_min));
        }

        for (int x = x_min; x <= x_max; x++) {
            int idx = x + y * width;

            if (iz - zb[idx] >= Z_BUF_DRAW_THRESHOLD) {
                zb[idx] = iz;
                fb[idx] = vector_to_color(rgb);
            }

            iz += iz_step;
            rgb = vec_add3(rgb, rgb_step);
        }

        x_l += x_l_step;
        x_r += x_r_step;
        iz_l += iz_l_step;
        iz_r += iz_r_step;
        rgb_l = vec_add3(rgb_l, rgb_l_step);
        rgb_r = vec_add3(rgb_r, rgb_r_step);
    }
}

static const int CLIP_PLANE_CNT = 5;
static ClipPlane CLIP_PLANES[5];

static void calculate_clipping_planes(void) {
    CLIP_PLANES[0] = (ClipPlane){{ 0, 0, 1}, -module.camera.dist };

    Vec3 left = normalize3((Vec3){ module.camera.dist, 0, module.camera.v_width });
    Vec3 right = normalize3((Vec3){ -module.camera.dist, 0, module.camera.v_width });
    Vec3 top = normalize3((Vec3){ 0, module.camera.dist, module.camera.v_height });
    Vec3 bottom = normalize3((Vec3){ 0, -module.camera.dist, module.camera.v_height });

    CLIP_PLANES[1] = (ClipPlane){ left, 0 };
    CLIP_PLANES[2] = (ClipPlane){ right, 0 };
    CLIP_PLANES[3] = (ClipPlane){ top, 0 };
    CLIP_PLANES[4] = (ClipPlane){ bottom, 0 };
}

typedef enum {
    CLIP_CLASS_IN_FRONT,
    CLIP_CLASS_MIXED,
    CLIP_CLASS_BEHIND
} ClipClass;

static ClipClass classify_sphere_clip(Vec3 center, float radius) {
    ClipClass classification = CLIP_CLASS_IN_FRONT;

    for (int i = 0; i < CLIP_PLANE_CNT; i++) {
        int dist = clip_signed_dist(CLIP_PLANES[i], center);

        if (dist < -radius) {
            return CLIP_CLASS_BEHIND;
        } else if (dist <= radius) {
            classification = CLIP_CLASS_MIXED;
        }
    }

    return classification;
}

static Vec3 plane_segment_intersect(ClipPlane plane, Vec3 v1, Vec3 v2, Vec3 vn1, Vec3 vn2, Vec3 *new_n_out) {
    Vec3 sub = vec_sub3(v2, v1);
    Vec3 nsub = vec_sub3(vn2, vn1);
    float t = (-plane.d - dot_prod3(plane.normal, v1)) / dot_prod3(plane.normal, sub);
    *new_n_out = vec_add3(vn1, scale3(nsub, t));
    return vec_add3(v1, scale3(sub, t));
}

static void render_clipped_tri(
    int cur_plane, 
    Vec3 v1, Vec3 v2, Vec3 v3, Vec3 vn1, Vec3 vn2, Vec3 vn3, color_t color
) {
    if (cur_plane < 0) {
        draw_triangle_3d(v1, v2, v3, vn1, vn2, vn3, color);
        return;
    }

    ClipPlane plane = CLIP_PLANES[cur_plane];

    bool v1_front = clip_signed_dist(plane, v1) >= 0;
    bool v2_front = clip_signed_dist(plane, v2) >= 0;
    bool v3_front = clip_signed_dist(plane, v3) >= 0;

    if (v1_front && v2_front && v3_front) {
        render_clipped_tri(cur_plane - 1, v1, v2, v3, vn1, vn2, vn3, color);
        return;
    }

    bool v1_behind = !v1_front;
    bool v2_behind = !v2_front;
    bool v3_behind = !v3_front;

    if (v1_behind && v2_behind && v3_behind) {
        // This triangle is behind a clipping plane don't render it.
        return;
    }

    if (v1_front && v2_behind && v3_behind) {
        Vec3 v2_new = plane_segment_intersect(plane, v1, v2, vn1, vn2, &vn2);
        Vec3 v3_new = plane_segment_intersect(plane, v1, v3, vn1, vn3, &vn3);
        render_clipped_tri(cur_plane - 1, v1, v2_new, v3_new, vn1, vn2, vn3, color);        
    } else if (v1_behind && v2_front && v3_behind) {
        Vec3 v1_new = plane_segment_intersect(plane, v2, v1, vn2, vn1, &vn1);
        Vec3 v3_new = plane_segment_intersect(plane, v2, v3, vn1, vn3, &vn3);
        render_clipped_tri(cur_plane - 1, v1_new, v2, v3_new, vn1, vn2, vn3, color);        
    } else if (v1_behind && v2_behind && v3_front) {
        Vec3 v1_new = plane_segment_intersect(plane, v3, v1, vn3, vn1, &vn1);
        Vec3 v2_new = plane_segment_intersect(plane, v3, v2, vn3, vn2, &vn2);
        render_clipped_tri(cur_plane - 1, v1_new, v2_new, v3, vn1, vn2, vn3, color);        
    } else if (v1_front && v2_front && v3_behind) {
        Vec3 vn1_inter, vn2_inter;
        Vec3 v1_inter = plane_segment_intersect(plane, v1, v3, vn1, vn3, &vn1_inter);
        Vec3 v2_inter = plane_segment_intersect(plane, v2, v3, vn2, vn3, &vn2_inter);
        render_clipped_tri(cur_plane - 1, v1, v2, v2_inter, vn1, vn2, vn2_inter, color);
        render_clipped_tri(cur_plane - 1, v1, v2_inter, v1_inter, vn1, vn2_inter, vn1_inter, color);
    } else if (v1_behind && v2_front && v3_front) {
        Vec3 vn2_inter, vn3_inter;
        Vec3 v2_inter = plane_segment_intersect(plane, v2, v1, vn2, vn1, &vn2_inter);
        Vec3 v3_inter = plane_segment_intersect(plane, v3, v1, vn2, vn1, &vn3_inter);
        render_clipped_tri(cur_plane - 1, v2, v3, v3_inter, vn2, vn3, vn3_inter, color);        
        render_clipped_tri(cur_plane - 1, v2, v3_inter, v2_inter, vn2, vn3_inter, vn2_inter, color);        
    } else if (v1_front && v2_behind && v3_front) {
        Vec3 vn1_inter, vn3_inter;
        Vec3 v1_inter = plane_segment_intersect(plane, v1, v2, vn1, vn2, &vn1_inter);     
        Vec3 v3_inter = plane_segment_intersect(plane, v3, v2, vn3, vn2, &vn3_inter);
        render_clipped_tri(cur_plane - 1, v3, v1, v1_inter, vn3, vn1, vn1_inter, color); 
        render_clipped_tri(cur_plane - 1, v3, v1_inter, v3_inter, vn3, vn1_inter, vn3_inter, color);   
    }
}

static void render_instance(InstanceIdx idx, Matrix4x4 cam_transformations, Matrix4x4 cam_rots) {
    Instance instance = module.instances[idx];
    Model model = module.models[instance.model];

    Matrix4x4 instance_rots = get_rot_matrix(instance.rotation);

    Matrix4x4 transformations = instance_rots;
    transformations = mat_mult(get_scale_matrix(instance.scale), transformations);
    transformations = mat_mult(get_translation_matrix(instance.position), transformations);
    transformations = mat_mult(cam_transformations, transformations);

    Matrix4x4 rotations = mat_mult(cam_rots, instance_rots);

    Vec3 model_center = homogenous_to_cartesian(mat_vec_mult(transformations, model.model_center));
    float model_radius = model.model_radius * instance.scale;
    ClipClass class = classify_sphere_clip(model_center, model_radius);

    // No need to render anything.
    if (class == CLIP_CLASS_BEHIND) return;

    Vec3 projected_vertices[model.vertex_cnt];
    for (int i = 0; i < model.vertex_cnt; i++) {
        projected_vertices[i] = homogenous_to_cartesian(mat_vec_mult(transformations, model.vertices[i]));
    }

    Vec3 projected_normals[model.normal_cnt];
    for (int i = 0; i < model.normal_cnt; i++) {
        projected_normals[i] = homogenous_to_cartesian(mat_vec_mult(rotations, model.normals[i]));
    }

    if (class == CLIP_CLASS_IN_FRONT) {
        for (TriangleIdx i = 0; i < model.triangle_cnt; i++) {
            // printf("render tri full %d/%d\n", i, model.triangle_cnt);
            Triangle tri = model.triangles[i];
            draw_triangle_3d(
                projected_vertices[tri.v1],
                projected_vertices[tri.v2],
                projected_vertices[tri.v3],
                projected_normals[tri.vn1],
                projected_normals[tri.vn2],
                projected_normals[tri.vn3],
                tri.color
            );
        }
    } else {
        for (TriangleIdx i = 0; i < model.triangle_cnt; i++) {
            // printf("render tri clipped %d/%d\n", i, model.triangle_cnt);
            Triangle tri = model.triangles[i];
            render_clipped_tri(
                CLIP_PLANE_CNT - 1,
                projected_vertices[tri.v1],
                projected_vertices[tri.v2],
                projected_vertices[tri.v3],
                projected_normals[tri.vn1],
                projected_normals[tri.vn2],
                projected_normals[tri.vn3],
                tri.color
            );
        }
    }
}

static void draw_char(int x, int y, char ch, color_t c) {
    unsigned char buf[font_get_glyph_size()];
    // Fill the buffer. If there is no character then there is nothing to do.
    if (!font_get_glyph(ch, buf, sizeof(buf))) return;

    // Reinterpret as a nice array.
    char (*img)[font_get_glyph_width()] = (char (*)[font_get_glyph_width()])buf;

    // Again we don't use draw_pixel for performance reasons.
    int glyph_width = font_get_glyph_width();
    int glyph_height = font_get_glyph_height();
    int screen_width = module.canvas.width;
    int screen_height = module.canvas.height;

    color_t (*screen_buf)[screen_width] = get_draw_buffer();

    for (int dx = 0; dx < glyph_width; dx++) {
        for (int dy = 0; dy < glyph_height; dy++) {
            int fx = x + dx;
            int fy = y + dy;

            if (img[dy][dx] == FONT_PIXEL_ON && fx >= 0 && fy >= 0 && fx < screen_width && fy < screen_height) {
                screen_buf[fy][fx] = c;
            }
        }
    }
}

static void draw_string(int x, int y, const char* str, color_t c) {
    if (y >= module.canvas.height) return;

    while (*str != '\0' && x < module.canvas.width) {
        draw_char(x, y, *str, c);
        x += font_get_glyph_width(); 
        str++; // move to the next character
    }
}

static void draw_debug_info(unsigned long elapsed_ticks) {
    long elapsed_us = elapsed_ticks / TICKS_PER_USEC;
    float elapsed_ms = (float)elapsed_us / 1000.0;
    int fps = (int)(1000.0 / elapsed_ms);

    char buf[1024];

    snprintf(buf, 1024, "%d FPS", fps);
    draw_string(10, 10, buf, GL3_BLACK);

    snprintf(buf, 1024, "(%d,%d,%d)|%d/%d", 
        (int)module.camera.position.x,
        (int)module.camera.position.y,
        (int)module.camera.position.z,
        (int)(module.camera.rotation.y * 180.0 / PI),
        (int)(module.camera.rotation.x * 180.0 / PI)
    );
    draw_string(10, 30, buf, GL3_BLACK);
}
