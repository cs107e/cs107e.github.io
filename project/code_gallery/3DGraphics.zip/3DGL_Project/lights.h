/* File: lights.h
 * ----------
 * Create and calculate the intensity of at specific points various lights.
 * 
 * Authors: Ege, Daniel
 */

#ifndef LIGHTS_H
#define LIGHTS_H

#include "linalg.h"
#include "geo3.h"

/* The type of a specific lights. Different lights have different properties
 * and behaviors. See Light for more information.
 */
typedef enum {
    LIGHT_POINT,
    LIGHT_AMBIENT,
    LIGHT_DIRECTIONAL
} LightType;

/* The characteristics of a given light source.
 */
typedef struct {
    LightType type;
    float intensity;
    color_t color;
    Vec3 position;
    Vec3 direction;
} Light;


#include "gl3.h"
#include "geo3.h"
#include "math.h"

// /* Calculate the intensity of the given lights at a given point in space based
//  * on the normal vector at that point.
//  */
static inline float light_intensity(Vec3 normal, Vec3 position, Light *lights, int light_cnt) {
    normal = normalize3(normal);

    float total_intensity = 0;

    for (int i = 0; i < light_cnt; i++) {
        if (lights[i].type == LIGHT_POINT) {
            Vec3 light_dir = normalize3(vec_sub3(position, lights[i].position));
            float angle_intensity = dot_prod3(normal, light_dir);
            if (angle_intensity > 0) total_intensity += lights[i].intensity * angle_intensity;
        } else if (lights[i].type == LIGHT_DIRECTIONAL) {
            float angle_intensity = dot_prod3(normal, lights[i].direction);
            if (angle_intensity > 0) total_intensity += lights[i].intensity * angle_intensity;
        } else if (lights[i].type == LIGHT_AMBIENT) {
            total_intensity += lights[i].intensity;
        }
    }

    return total_intensity;
}

static inline Vec3 color_to_vector(color_t color) {
    return (Vec3){
        ( color >> 16 ) & 0xFF,
        ( color >> 8  ) & 0xFF,
        ( color >> 0  ) & 0xFF
    };
}

// with clamping
static inline color_t vector_to_color(Vec3 rgb) {
    return (0xff << 24) 
        | ((255 < (int)rgb.x ? 255 : (int)rgb.x) << 16)
        | ((255 < (int)rgb.y ? 255 : (int)rgb.y) << 8 )
        | ((255 < (int)rgb.z ? 255 : (int)rgb.z)      );
}

// /* Returns the color of a point at a particular point in space given its
//  * base color, normal vector, and a list of all the lights in the scene.
//  */
static inline Vec3 light_color(color_t color, Vec3 normal, Vec3 position, Light *lights, LightIdx light_cnt) {  
    Vec3 rgb = color_to_vector(color);   
    float intensity = light_intensity(normal, position, lights, light_cnt);
    rgb = scale3(rgb, intensity);
    return rgb;
}


/* Creates a new ambient light with given intensity. Ambient lights apply
 * this intensity equally to all points in the scene.
 */
static inline Light gl3_new_ambient_light(float intensity) {
    return (Light) {
        LIGHT_AMBIENT,
        intensity,
        0xffffffff,
        { 0, 0, 0 },
        { 0, 0, 0 }
    };
}

/* Creates a new point light with given intensity and position. Point lights
 * exists at a certain position in space and send out light equally in all 
 * directions. The intensity at a specific point is based off of the angle
 * between the normal vector and the vector to the light.
 */
static inline Light gl3_new_point_light(float intensity, Vec3 position) {
    return (Light) {
        LIGHT_POINT,
        intensity,
        0xffffffff,
        position,
        { 0, 0, 0 }
    };
}

/* Creates a new direction light with given intensity and direction. The
 * intensity of the light from a directional light is dependent on the angle
 * between the normal vector and the direction of the directional light.
 * 
 * This is good for lights that are very far away such as the Sun.
 */
static inline Light gl3_new_directional_light(float intensity, Vec3 direction) {
    return (Light) {
        LIGHT_DIRECTIONAL,
        intensity,
        0xffffffff,
        { 0, 0, 0 },
        direction     
    };
}

#endif