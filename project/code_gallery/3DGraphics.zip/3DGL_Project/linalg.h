/* File: linalg.h
 * ----------
 * Linear algebra structures and operations.
 */

#ifndef LINALG_H
#define LINALG_H

/* A two dimensional integer point for representing a position on the canvas.
 */
typedef struct { 
    int x, y;
} CanvasVec;

/* A three dimensional vector of floating point numbers.
 */
typedef struct { 
    float x, y, z;
} Vec3;

/* A four dimensional vector of floating point numbers. 
 *
 * This is useful to represent 3-vectors using homogenous coordinates.
 */
typedef struct {
    float x, y, z, w;
} Vec4;

/* A four by four matrix of floating point numbers. 
 *
 * This is mainly useful for doing linear transformations of `Vec4`s which
 * correspond to affine transformations of the underlying 3-vectors.
 * 
 * The entries of the matrix are in row-major order.
 */
typedef struct {
    float entries[16];
} Matrix4x4;

#include "math.h"

// -------------------------- Vector Addition ----------------------------------

static inline Vec3 vec_add3(Vec3 v1, Vec3 v2) {
    return (Vec3){
        .x = v1.x + v2.x,
        .y = v1.y + v2.y,
        .z = v1.z + v2.z
    };
}

static inline Vec3 vec_sub3(Vec3 v1, Vec3 v2) {
    return (Vec3){
        .x = v1.x - v2.x,
        .y = v1.y - v2.y,
        .z = v1.z - v2.z
    };
}

// ----------------------- Vector & Matrix Scaling -----------------------------

static inline Vec3 scale3(Vec3 v, float alpha) {
    return (Vec3){
        .x = v.x * alpha,
        .y = v.y * alpha,
        .z = v.z * alpha
    };
}

static inline Vec4 scale4(Vec4 v, float alpha) {
    return (Vec4){
        .x = v.x * alpha,
        .y = v.y * alpha,
        .z = v.z * alpha,
        .w = v.w
    };
}

static inline Matrix4x4 scale_mat4x4(Matrix4x4 m, float alpha) {
    Matrix4x4 scaledMat;
    for (int i = 0; i < 16; i++) {
        scaledMat.entries[i] = alpha * m.entries[i];
    }
    return scaledMat;
}

static inline float mag3(Vec3 v) {
    return fsqrt(v.x * v.x + v.y * v.y + v.z * v.z);
}

static inline Vec3 normalize3(Vec3 v) {
    float mag = mag3(v);
    return scale3(v, 1 / mag);
}

// ----------------------- Dot products of vectors -----------------------------

static inline float dot_prod3(Vec3 v1, Vec3 v2) {
    return v1.x * v2.x + v1.y * v2.y + v1.z * v2.z;
}

static inline float dot_prod4(Vec4 v1, Vec4 v2) {
    return v1.x * v2.x + v1.y * v2.y + v1.z * v2.z + v1.w * v2.w;
}

// ---------------------- Cross products of vectors ----------------------------

static inline Vec3 cross_prod3(Vec3 v1, Vec3 v2) {
    return (Vec3){
        .x = v1.y * v2.z - v1.z * v2.y,
        .y = v1.z * v2.x - v1.x * v2.z,
        .z = v1.x * v2.y - v1.y * v2.x,
    };
}

// --------------------------- Matrix Products ---------------------------------

static inline Vec4 mat_vec_mult(Matrix4x4 m, Vec4 v) {
    return (Vec4){
        .x = m.entries[0]  * v.x + m.entries[1]  * v.y + m.entries[2]  * v.z + m.entries[3]  * v.w,
        .y = m.entries[4]  * v.x + m.entries[5]  * v.y + m.entries[6]  * v.z + m.entries[7]  * v.w,
        .z = m.entries[8]  * v.x + m.entries[9]  * v.y + m.entries[10] * v.z + m.entries[11] * v.w,
        .w = m.entries[12] * v.x + m.entries[13] * v.y + m.entries[14] * v.z + m.entries[15] * v.w
    };
}

static inline Matrix4x4 mat_mult(Matrix4x4 m1, Matrix4x4 m2) {
    Matrix4x4 result;

    for (int i = 0; i < 4; i++) {           // iterate rows
        for (int j = 0; j < 4; j++) {       // iterate columns
            result.entries[i * 4 + j] = 0;  // initialize the result entry to 0
            for (int k = 0; k < 4; k++) {   // row i, column j given by dot product between row i of m1 and column j of m2
                result.entries[i * 4 + j] += m1.entries[i * 4 + k] * m2.entries[k * 4 + j];
            }
        }
    }

    return result;
}

// ------------------------- Transformation Matrices ---------------------------

static inline Matrix4x4 get_rot_matrix(Vec3 rotations) {
    // The formula for the rotation matrix is as described in this article:
    // https://support.zemax.com/hc/en-us/articles/1500005576822-Rotation-Matrix-and-Tilt-About-X-Y-Z-in-OpticStudio

    float cx = cos(-rotations.x);
    float sx = sin(-rotations.x);
    float cy = cos(-rotations.y);
    float sy = sin(-rotations.y);
    float cz = cos(-rotations.z);
    float sz = sin(-rotations.z);

    return (Matrix4x4){{
        cy * cz,                -cy * sz,                 sy,      0,
        cx * sz + sx * sy * cz,  cx * cz - sx * sy * sz, -sx * cy, 0,
        sx * sz - cx * sy * cz,  sx * cz + cx * sy * sz,  cx * cy, 0,
        0,                       0,                       0,       1
    }};
}

static inline Matrix4x4 get_scale_matrix(float a) {
    return (Matrix4x4){{
        a, 0, 0, 0,
        0, a, 0, 0,
        0, 0, a, 0,
        0, 0, 0, 1
    }};
}

static inline Matrix4x4 get_translation_matrix(Vec3 translation) {
    return (Matrix4x4){{
        1, 0, 0, translation.x,
        0, 1, 0, translation.y,
        0, 0, 1, translation.z,
        0, 0, 0, 1
    }};
}

// ----------------- Homogenous & Cartesian Coordinates ------------------------

static inline Vec3 homogenous_to_cartesian(Vec4 v4) {
    return (Vec3){
        .x = v4.x / v4.w,
        .y = v4.y / v4.w,
        .z = v4.z / v4.w
    };
}

static inline Vec4 cartesian_to_homogenous(Vec3 v3) {
    return (Vec4){
        .x = v3.x,
        .y = v3.y,
        .z = v3.z,
        .w = 1
    };
}

#endif