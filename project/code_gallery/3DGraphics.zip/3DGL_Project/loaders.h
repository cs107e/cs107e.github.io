/* File: loaders.h
 * ----------
 * Load various model files to a gl3 model.
 * 
 * Authors: Daniel, Ege
 */

#ifndef LOADERS_H
#define LOADERS_H

#include "geo3.h"
#include "gl3.h"
#include "stdbool.h"

/* Parses the given data as a *binary not ascii* stl file. If the file
 * is parsed successfully the model is written to model_out and true is
 * returned. If there is a parsing error false is returned. 
 */
bool gl3_load_binary_stl(unsigned char *model_data, int model_len, color_t color, Model *model_out);

/* Parses the given data as an obj file. 
 * Only collects vertex and normal data.
 * If the file is parsed successfully the model is written to model_out
 * and true is returned. If there is a parsing error false is returned. 
 */
bool gl3_load_obj(const char *model_data, int model_len, color_t color, Model *model_out);

#endif