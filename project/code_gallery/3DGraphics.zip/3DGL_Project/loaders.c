#include "loaders.h"
#include "strings.h"
#include "printf.h"
#include "geo3.h"

#define STL_BIN_HEADER_SIZE 80
#define STL_BIN_TRI_SIZE 50

typedef struct {
    float nx, ny, nz;
    float v1x, v1y, v1z;
    float v2x, v2y, v2z;
    float v3x, v3y, v3z;
    unsigned short attributes;
} StlModelFace;

bool gl3_load_binary_stl(unsigned char *model_data, int model_len, color_t color, Model *model_out) {
    // STL binary format as described here https://en.wikipedia.org/wiki/STL_(file_format)#Binary

    if (model_len < STL_BIN_HEADER_SIZE + sizeof(unsigned int)) return false;
    model_data += STL_BIN_HEADER_SIZE; // Skip initial header.

    unsigned int tri_cnt = *(unsigned int *)model_data;
    int vertex_cnt = tri_cnt * 3;
    model_data += sizeof(unsigned int);

    if (model_len < STL_BIN_HEADER_SIZE + sizeof(unsigned int) + tri_cnt * STL_BIN_TRI_SIZE) return false;

    Vec3 vertices[vertex_cnt];
    Triangle triangles[tri_cnt];

    for (int i = 0; i < tri_cnt; i++) {
        StlModelFace stl_face = *(StlModelFace *)&model_data[i * 50];
        vertices[i * 3 + 0] = (Vec3){ stl_face.v1x, stl_face.v1y, stl_face.v1z };
        vertices[i * 3 + 1] = (Vec3){ stl_face.v2x, stl_face.v2y, stl_face.v2z };
        vertices[i * 3 + 2] = (Vec3){ stl_face.v3x, stl_face.v3y, stl_face.v3z };
        triangles[i] = (Triangle){ i * 3, i * 3 + 1, i * 3 + 2, NO_NORMAL, NO_NORMAL, NO_NORMAL, color };
    }

    *model_out = new_model(vertices, NULL, triangles, vertex_cnt, 0, tri_cnt);
    return true;
}

void advance_to_next_line(const char **str) {
    while (**str != '\n' && **str != '\0') *str = *str + 1;
    *str = *str + 1;
}

#define INVALID_DIG (-1)

int char_to_dig(char c) {
    if (c >= '0' && c <= '9') {
        return c - '0';
    } else {
        return INVALID_DIG;
    }
}

float pop_float_from_str(const char **str) {
    float val = 0;

    bool neg = false;
    if (**str == '-') {
        neg = true;
        *str = *str + 1;
    }

    while (char_to_dig(**str) != INVALID_DIG) {
        int dig = char_to_dig(**str);
        val *= 10;
        val += dig;
        *str = *str + 1;
    }

    if (**str == '.') {
        *str = *str + 1;

        float base = 1;
        while (char_to_dig(**str) != INVALID_DIG) {
            int dig = char_to_dig(**str);
            base /= 10.0;
            val += dig * base;
            *str = *str + 1;
        }
    }

    return neg ? -val : val;    
}

Vec3 pop_vec3_from_str(const char **str) {
    float x = pop_float_from_str(str);
    *str = *str + 1; // ' '
    float y = pop_float_from_str(str);
    *str = *str + 1; // ' '
    float z = pop_float_from_str(str);
    return (Vec3){ x, y, z };
}

Triangle pop_tri_from_str(const char **str, color_t color) {
    int v1_idx = strtonum(*str, str);
    *str = *str + 1; // '/'
    int v1t_idx = strtonum(*str, str);
    *str = *str + 1; // '/'
    int v1n_idx = strtonum(*str, str);
    *str = *str + 1; // ' '
    int v2_idx = strtonum(*str, str);
    *str = *str + 1; // '/'
    int v2t_idx = strtonum(*str, str);
    *str = *str + 1; // '/'
    int v2n_idx = strtonum(*str, str);
    *str = *str + 1; // ' '
    int v3_idx = strtonum(*str, str);
    *str = *str + 1; // '/'
    int v3t_idx = strtonum(*str, str);
    *str = *str + 1; // '/'
    int v3n_idx = strtonum(*str, str);

    return (Triangle) { 
        v1_idx - 1, v2_idx - 1, v3_idx - 1, 
        v1n_idx - 1, v2n_idx - 1, v3n_idx -1,  
        color 
    };
}

#define MAX_VTX 4096
#define MAX_TRI 1024

bool gl3_load_obj(const char *model_data, int model_len, color_t color, Model *model_out) {
    Vec3 vtx[MAX_VTX];
    int vtx_cnt = 0;

    Vec3 vtx_norm[MAX_VTX];
    int vtx_norm_cnt = 0;

    Triangle tris[MAX_TRI];
    int tri_cnt = 0;

    while (*model_data != '\0') {
        switch(*model_data) {
            case 'v':
                model_data++; // 'v'
                if (*model_data == ' ') {
                    model_data++; // ' '
                    vtx[vtx_cnt++] = pop_vec3_from_str(&model_data);
                } else if (*model_data == 'n') {
                    model_data++; // 'n'
                    model_data++; // ' '
                    vtx_norm[vtx_norm_cnt++] = pop_vec3_from_str(&model_data);
                }
                break;
            case 'f':
                model_data++; // f
                model_data++; // ' '
                tris[tri_cnt++] = pop_tri_from_str(&model_data, color);
                break;
        }
        advance_to_next_line(&model_data);
    }
    
    printf("%d vtx, %d tri\n", vtx_cnt, tri_cnt);

    *model_out = new_model(vtx, vtx_norm, tris,  vtx_cnt, vtx_norm_cnt, tri_cnt);
    return true;
}