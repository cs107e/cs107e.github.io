.attribute arch, "rv64imdac_zicsr"

.globl enable_floats
enable_floats:
    li a0, 1<<13
    csrc mstatus, a0
    li a0, 1<<14
    csrs mstatus, a0
    ret

.globl fsqrt
fsqrt:
    fmv.w.x fa0, a0
    fsqrt.s fa0, fa0
    fmv.x.w a0, fa0
    ret
