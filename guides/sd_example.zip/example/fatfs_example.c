#include "printf.h"
#include "strings.h"
#include "malloc.h"
#include "ff.h"

#define TESTFILE "testfile.txt"

// comment out the line below to leave the file on the SD card
#define REMOVE_FILE

// see ff.h for information about error codes

void main() {
    FATFS fs;
    FRESULT res;
    // mount the internal SD card 
    res = f_mount(&fs, "", 1);
    if (res != FR_OK) {
        printf("Could not mount internal SD card. Error: %d\n",res);
        return;
    }
    printf("Mounted SD card.\n");

    // create a test file in the root directory
    // see http://elm-chan.org/fsw/ff/doc/open.html
    // for information about the f_open function
    printf("Creating file %s on the SD card.\n",TESTFILE); 
    FIL fp;
    res = f_open(&fp, TESTFILE, FA_CREATE_ALWAYS | FA_WRITE);
    if (res != FR_OK) {
        printf("Could not create %s file. Error: %d\n",TESTFILE, res);
        return;
    }

    // write something to the file
    // see http://elm-chan.org/fsw/ff/doc/write.html
    // for information about the f_write function
    char *buf = "Shall we play a game?\nLove to. How about Global Thermonuclear War?\n";
    unsigned int bytes_to_write = strlen(buf); 
    unsigned int bytes_written;
    res = f_write(&fp,buf,bytes_to_write,&bytes_written);
    if (res != FR_OK) {
        printf("Could not write to file %s. Error: %d\n", TESTFILE, res);
        f_close(&fp);
        return;
    }
    printf("Wrote:\n%s\n\nto %s, and wrote a total of %d bytes.\n",buf,TESTFILE,bytes_written); 
    f_close(&fp);

    // we are going to read the entire file, so we can use the f_stat function 
    // to get the file length, and we can also use this to determine if the file exists
    // see http://elm-chan.org/fsw/ff/doc/stat.html
    // for information about the f_stat function
    // The file information struct details can be seen at
    // http://elm-chan.org/fsw/ff/doc/sfileinfo.html
    FILINFO fno;
    res = f_stat(TESTFILE,&fno);
    if (res != FR_OK) {
        printf("Could not run f_stat on %s. Error:%d\n", TESTFILE, res);
        return;
    }

    // open the file up again to read it
    res = f_open(&fp, TESTFILE, FA_READ);
    if (res != FR_OK) {
        printf("Could not open %s file for reading. Error:%d\n",TESTFILE,res);
        return;
    }
    // read the entire file into a buffer
    // see http://elm-chan.org/fsw/ff/doc/read.html
    // for information about the f_read function
    char *readbuf = malloc(fno.fsize + 1);
    unsigned int bytes_read;
    res = f_read(&fp, readbuf, fno.fsize, &bytes_read);
    if (res != FR_OK) {
        printf("Could not read from file %s. Error: %d\n",TESTFILE,res);
        return;
    }
    printf("Read the following from %s:\n",TESTFILE);
    printf("%s\n\n",readbuf);
    printf("Read a total of %d bytes.\n",bytes_read);

    free(readbuf); 

#ifdef REMOVE_FILE
    // remove the file
    // see http://elm-chan.org/fsw/ff/doc/unlink.html
    // for information about the f_unlink function
    res = f_unlink(TESTFILE);
    if (res != FR_OK) {
        printf("Could not remove file: %s.\n",TESTFILE);
        return;
    }
    printf("Removed %s from the SD card.\n",TESTFILE);

    // close connection
    printf("\n%c",0x04);
#endif
}
