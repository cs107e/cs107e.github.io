Example program for SD card mounting, reading, writing, and deleting.

See <a href="http://elm-chan.org/fsw/ff/00index_e.html">FatFs - Generic FAT Filesystem Module</a> for information about the FATfs file system.

